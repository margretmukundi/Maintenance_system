-- ================================================================
-- OFFICE MAINTENANCE REQUEST SYSTEM — database.sql  v5.0
-- Engine  : MySQL 8.0+
-- Backend : Node.js + Express v5.0
-- ================================================================
-- CHANGES FROM v4.0:
--   - Added users.email_verified column
--   - Added email_verification_tokens table (new)
--   - Added maintenance_requests.photo_path column
--   - Added users.must_change_password column (for first-login flow)
-- ================================================================
-- HOW TO IMPORT:
--   1. Open http://localhost/phpmyadmin
--   2. Click "New" → name it maintenance_db → Create
--   3. Click maintenance_db → Import tab → choose this file → Go
-- ================================================================

SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------
-- TABLE: departments
-- ----------------------------------------------------------------
DROP TABLE IF EXISTS departments;
CREATE TABLE departments (
  id        SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name      VARCHAR(100)      NOT NULL,
  is_active TINYINT(1)        NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uq_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- TABLE: item_catalogue
-- ----------------------------------------------------------------
DROP TABLE IF EXISTS item_catalogue;
CREATE TABLE item_catalogue (
  id         SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  item_key   VARCHAR(60)       NOT NULL,
  item_label VARCHAR(120)      NOT NULL,
  icon       VARCHAR(20)       DEFAULT NULL,
  is_active  TINYINT(1)        NOT NULL DEFAULT 1,
  sort_order TINYINT UNSIGNED  NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uq_key (item_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- TABLE: users
-- NEW COLUMNS: email_verified, must_change_password
-- ----------------------------------------------------------------
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id                  INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  name                VARCHAR(120)  NOT NULL,
  department          VARCHAR(100)  NOT NULL,
  floor_office        VARCHAR(100)  NOT NULL,
  designation         VARCHAR(100)  NOT NULL,
  email               VARCHAR(180)  NOT NULL,
  password_hash       VARCHAR(255)  NOT NULL COMMENT 'bcrypt — never plain text',
  role                ENUM('user','admin') NOT NULL DEFAULT 'user',
  email_verified      TINYINT(1)    NOT NULL DEFAULT 0,
  must_change_password TINYINT(1)   NOT NULL DEFAULT 0 COMMENT 'Set 1 to force password change on next login',
  is_active           TINYINT(1)    NOT NULL DEFAULT 1,
  created_at          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_email (email),
  KEY idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- TABLE: admin_tokens  (8-hour admin session tokens)
-- ----------------------------------------------------------------
DROP TABLE IF EXISTS admin_tokens;
CREATE TABLE admin_tokens (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id    INT UNSIGNED NOT NULL,
  token      VARCHAR(128) NOT NULL,
  expires_at DATETIME     NOT NULL,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_token (token),
  KEY idx_expires (expires_at),
  CONSTRAINT fk_token_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- TABLE: password_reset_tokens
-- NOTE: This table is named password_reset_tokens (not
--       password_resets). The server always uses this name.
-- ----------------------------------------------------------------
DROP TABLE IF EXISTS password_reset_tokens;
CREATE TABLE password_reset_tokens (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id    INT UNSIGNED NOT NULL,
  token      VARCHAR(20)  NOT NULL,
  expires_at DATETIME     NOT NULL,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_user (user_id),
  CONSTRAINT fk_reset_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- TABLE: email_verification_tokens  (NEW in v5.0)
-- Used to verify email address on registration
-- ----------------------------------------------------------------
DROP TABLE IF EXISTS email_verification_tokens;
CREATE TABLE email_verification_tokens (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id    INT UNSIGNED NOT NULL,
  token      VARCHAR(10)  NOT NULL,
  expires_at DATETIME     NOT NULL,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_user (user_id),
  CONSTRAINT fk_verif_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- TABLE: sessions  (express-session MySQL store)
-- ----------------------------------------------------------------
DROP TABLE IF EXISTS sessions;
CREATE TABLE sessions (
  session_id VARCHAR(128)  NOT NULL,
  expires    INT UNSIGNED  NOT NULL,
  data       MEDIUMTEXT    DEFAULT NULL,
  PRIMARY KEY (session_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- TABLE: maintenance_requests
-- NEW COLUMN: photo_path (optional image for repair requests)
-- ----------------------------------------------------------------
DROP TABLE IF EXISTS maintenance_requests;
CREATE TABLE maintenance_requests (
  id                INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  user_id           INT UNSIGNED  NOT NULL,
  request_type      ENUM('new_item','repair') NOT NULL,
  item_name         VARCHAR(120)  NOT NULL,
  priority          ENUM('low','med','high') NOT NULL DEFAULT 'med',
  status            ENUM('pending','approved','in_progress','completed','rejected') NOT NULL DEFAULT 'pending',
  notes             TEXT          DEFAULT NULL,
  admin_notes       TEXT          DEFAULT NULL,
  quantity          SMALLINT UNSIGNED DEFAULT NULL,
  required_by       DATE          DEFAULT NULL,
  asset_tag         VARCHAR(60)   DEFAULT NULL,
  issue_description TEXT          DEFAULT NULL,
  preferred_date    DATE          DEFAULT NULL,
  photo_path        VARCHAR(255)  DEFAULT NULL COMMENT 'Relative path to uploaded repair photo, e.g. /uploads/filename.jpg',
  created_at        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_req_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE RESTRICT ON UPDATE CASCADE,
  KEY idx_user_id    (user_id),
  KEY idx_status     (status),
  KEY idx_type       (request_type),
  KEY idx_priority   (priority),
  KEY idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- TABLE: request_audit_log
-- ----------------------------------------------------------------
DROP TABLE IF EXISTS request_audit_log;
CREATE TABLE request_audit_log (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  request_id   INT UNSIGNED NOT NULL,
  changed_by   INT UNSIGNED DEFAULT NULL,
  old_status   ENUM('pending','approved','in_progress','completed','rejected') DEFAULT NULL,
  new_status   ENUM('pending','approved','in_progress','completed','rejected') NOT NULL,
  comment      TEXT         DEFAULT NULL,
  changed_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_log_req FOREIGN KEY (request_id)
    REFERENCES maintenance_requests (id) ON DELETE CASCADE,
  CONSTRAINT fk_log_admin FOREIGN KEY (changed_by)
    REFERENCES users (id) ON DELETE SET NULL,
  KEY idx_req (request_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- TABLE: email_log
-- ----------------------------------------------------------------
DROP TABLE IF EXISTS email_log;
CREATE TABLE email_log (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  request_id INT UNSIGNED DEFAULT NULL,
  recipient  VARCHAR(180) NOT NULL,
  subject    VARCHAR(255) NOT NULL,
  body       MEDIUMTEXT   DEFAULT NULL,
  status     ENUM('sent','failed') NOT NULL DEFAULT 'sent',
  error_msg  VARCHAR(500) DEFAULT NULL,
  sent_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_req    (request_id),
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- SEED DATA
-- ================================================================

INSERT INTO departments (name) VALUES
  ('Administration'), ('Finance & Accounts'), ('Human Resources'),
  ('ICT & Systems'), ('Legal & Compliance'), ('Operations'),
  ('Procurement'), ('Strategy & Planning'), ('Other');

INSERT INTO item_catalogue (item_key, item_label, icon, sort_order) VALUES
  ('desk',             'Desk',                         '🖥️', 1),
  ('desk_side_drawer', 'Desk & Side Drawer',            '🗂️', 2),
  ('side_drawer',      'Side Drawer',                   '📂', 3),
  ('office_chair',     'Office Chair',                  '🪑', 4),
  ('coat_hanger',      'Coat Hanger',                   '🪝', 5),
  ('metallic_cabinet', 'Metallic Cabinet',              '🗄️', 6),
  ('mdf_cabinet',      'MDF Low Level Cabinet',         '📦', 7),
  ('double_cabinet',   'Double Door Metallic Cabinet',  '🚪', 8),
  ('visitor_chair',    'Visitor Chair',                 '💺', 9);

-- ================================================================
-- ADMIN ACCOUNT SEED
-- !! CHANGE PASSWORD IMMEDIATELY AFTER FIRST LOGIN !!
-- Email:    admin@organisation.com
-- Password: Admin@1234
-- Hash generated with: bcrypt.hashSync('Admin@1234', 12)
-- NOTE: Admin accounts are pre-verified (email_verified = 1)
-- ================================================================
INSERT INTO users (name, department, floor_office, designation, email, password_hash, role, email_verified)
VALUES (
  'System Administrator',
  'Administration',
  'Ground Floor, Admin Office',
  'Facilities Manager',
  'admin@organisation.com',
  '$2b$12$9YdpQ.NFSJUfFdlAFvCCO.nGdqHMYXXJMI5V3WqP4K8PpKl9hO5Di',
  'admin',
  1
);

-- ================================================================
-- VIEWS
-- ================================================================
CREATE OR REPLACE VIEW v_pending_requests AS
SELECT mr.id, mr.request_type, mr.item_name, mr.priority, mr.status,
       DATE_FORMAT(mr.created_at,'%d %b %Y %H:%i') AS created_at,
       u.name AS requester, u.department, u.floor_office, u.email
FROM maintenance_requests mr JOIN users u ON u.id = mr.user_id
WHERE mr.status = 'pending'
ORDER BY FIELD(mr.priority,'high','med','low'), mr.created_at ASC;

CREATE OR REPLACE VIEW v_request_summary AS
SELECT u.department, mr.status, COUNT(*) AS total
FROM maintenance_requests mr JOIN users u ON u.id = mr.user_id
GROUP BY u.department, mr.status ORDER BY u.department;

SET FOREIGN_KEY_CHECKS = 1;

-- ================================================================
-- STATUS WORKFLOW:
--   pending → approved → in_progress → completed
--   any stage → rejected
-- ================================================================

-- ================================================================
-- MIGRATION SCRIPT (run this if you already have a v4.0 database
-- and want to upgrade without wiping data):
-- ================================================================
-- ALTER TABLE users
--   ADD COLUMN email_verified TINYINT(1) NOT NULL DEFAULT 0 AFTER email,
--   ADD COLUMN must_change_password TINYINT(1) NOT NULL DEFAULT 0 AFTER email_verified;
--
-- UPDATE users SET email_verified = 1 WHERE role = 'admin';
-- UPDATE users SET email_verified = 1;  -- mark all existing users verified
--
-- ALTER TABLE maintenance_requests
--   ADD COLUMN photo_path VARCHAR(255) DEFAULT NULL AFTER issue_description;
--
-- CREATE TABLE IF NOT EXISTS email_verification_tokens (
--   id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
--   user_id INT UNSIGNED NOT NULL,
--   token VARCHAR(10) NOT NULL,
--   expires_at DATETIME NOT NULL,
--   created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
--   UNIQUE KEY uq_user (user_id),
--   CONSTRAINT FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- ================================================================
